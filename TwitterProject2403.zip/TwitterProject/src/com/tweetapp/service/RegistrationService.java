package com.tweetapp.service;

import java.util.Scanner;

import com.tweetapp.dao.RegistrationDao;
import com.tweetapp.model.Register;

public class RegistrationService {

	static boolean flag = false;
	static boolean isValidEmail = false;
	static boolean isValPass = false;
	static boolean isValDob = false;
	static InputValidation inputValidation = new InputValidation();

	public static void register() {

		Scanner sc = new Scanner(System.in);

		System.out.println("==========================================");
		System.out.println("Enter first name :");
		String name = sc.nextLine();

		System.out.println("Enter last name");
		String lname = sc.nextLine();

		System.out.println("Enter gender");
		String city = sc.nextLine();

		System.out.println("Enter dob");
		String dob = sc.nextLine();
		isValDob = inputValidation.valDob(dob);
		if (isValDob) {
			System.out.println("Valid dob");
		} else {
			System.out.println("Invalid dob");
		}

		System.out.println("Enter email");
		String email = sc.nextLine();
		isValidEmail = inputValidation.valEmail(email);

		System.out.println("Enter password");
		String password = sc.nextLine();

		isValPass = inputValidation.valPwd(password);
		if (isValidEmail && isValPass && isValDob) {
			flag = true;
		} else {
			flag = false;
		}

		System.out.println("==========================================");

		Register register = new Register(name, lname, city, dob, email, password);
		boolean answer = RegistrationDao.insertUserToDb(register);
		// create student object to store student
		if (answer && flag) {
			System.out.println("Sucessfully registered for the app..");
		} else {
			System.out.println("Please check email password and dob and try again...");
		}

	}
}