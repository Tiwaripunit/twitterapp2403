package com.tweetapp.service;

import java.util.Scanner;

import com.tweetapp.dao.ResetDao;

public class ResetPasswordService {

	static InputValidation inputValidation = new InputValidation();
	static boolean isEmailValid = false;
	static boolean isPasswordValid = false;
	static boolean isPasswordValid1 = false;
	static boolean flag = false;

	public static void reset() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter user name :");
		String email = sc.nextLine();
		System.out.println("========================================");
		isEmailValid = inputValidation.valEmail(email);
		System.out.println("Enter new password");
		String password = sc.nextLine();
		isPasswordValid = inputValidation.valPwd(password);
		System.out.println("========================================");
		System.out.println("Confirm Password");
		String password1 = sc.nextLine();
		if (isEmailValid && isPasswordValid && isPasswordValid1) {
			flag = true;
		}
		isPasswordValid = inputValidation.valPwd(password);
		if (password.equals(password1) && flag) {
			boolean answer = ResetDao.resetPasswordDb(email, password);
			if (answer) {
				System.out.println("========================================");
				System.out.println("Reset Password is successfull. Thank You!!");
				System.out.println("========================================");
			}
		} else if (!password.equals(password1) && flag) {
			System.out.println("===================================================");
			System.out.println("Entered passwords didn't match.. Please try again");
			System.out.println("====================================================");
		} else {
			System.out.println("===================================================");
			System.out.println("Please check your email and password");
			System.out.println("===================================================");
		}
	}
}
