package com.tweetapp.service;

import java.time.LocalDateTime;
import java.util.Scanner;

import com.tweetapp.dao.LoginDao;
import com.tweetapp.dao.PostTweetDao;

public class LoginService {

	static InputValidation inputValidation = new InputValidation();
	String isLoginEmail = null;
	static boolean isEmailValid = false;
	static boolean isPasswordValid = false;
	static boolean flag = false;

	public static void login() {
		String isLoginEmail = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter username => ");
		String email = sc.nextLine();
		// register.setEmail(username);
		isEmailValid = inputValidation.valEmail(email);

		System.out.println();
		System.out.println("Enter password");
		String password = sc.nextLine();
		isPasswordValid = inputValidation.valPwd(password);
		if (isEmailValid && isPasswordValid) {
			flag = LoginDao.validateLoginDb(email, password);
		}

		System.out.println();

		boolean answer = LoginDao.validateLoginDb(email, password);
		if (answer && flag) {
			isLoginEmail = email;
		} else {
			isLoginEmail = null;
		}

		// register.setPassword(password);

		// boolean flag = register(register);
		if (answer && flag) {
			System.out.println("Sucessfully Logged In");
			while (true) {
				System.out.println("====================================");
				System.out.println("PRESS 1 to Post tweets");
				System.out.println("PRESS 2 to View all tweets");
				System.out.println("PRESS 3 to View my tweets");
				System.out.println("PRESS 4 to Logout app");
				System.out.println("====================================");
				System.out.print("Enter the choice : ");
				int d = Integer.parseInt(sc.nextLine());
				if (d == 1) {
					try {
						Scanner sd = new Scanner(System.in);
						System.out.println("Enter tweet");
						String messages = sd.nextLine();

						String time = LocalDateTime.now().toString();
						boolean flag = PostTweetDao.insertInDb(messages, isLoginEmail, time);
						System.out.println(flag);
						if (flag) {
							System.out.println("Tweet is posted..");
						} else {
							System.out.println("Something went wrong..");
						}

					} finally {

					}

				} else if (d == 2) {
					System.out.println("Show all tweet");
					ViewAllTweet.viewAllTweet();
					// break;
				} else if (d == 3) {
					System.out.println("Show my tweet");
					ViewMyTweet.viewMyTweet(isLoginEmail);
					// break;
				} else if (d == 4) {
					System.out.println("Yoh have successfully logged out of the application");
					isLoginEmail = null;
					break;
				}

			}
		} else {

			System.out.println(("Something went wrong "));
		}
		// break;
	}
}