package com.tweetapp.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidation {

	public static boolean valEmail(String input) {
		boolean flag = false;
		String emailRegex = "^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
		Pattern emailPat = Pattern.compile(emailRegex, Pattern.CASE_INSENSITIVE);
		Matcher matcher = emailPat.matcher(input);
		return matcher.find();
	}

	public static boolean valPwd(String pass) {
		String pwdRegex = "^" + "(?=.*[@#$%^&+=])" + // at least 1 special character
				"(?=\\S+$)" + // no white spaces
				".{4,}" + // at least 4 characters
				"$";
		Pattern pwdPat = Pattern.compile(pwdRegex);
		Matcher matcher = pwdPat.matcher(pass);
		return matcher.matches();
	}

	public static boolean valPhone(String phone) {
		String phoneRegex = "^(\\+91[\\-\\s]?)?[0]?(91)?[789]\\d{9}$";
		Pattern phonePat = Pattern.compile(phoneRegex);
		Matcher matcher = phonePat.matcher(phone);
		return matcher.matches();
	}

	public static boolean valDob(String dob) {
		String dobRegex = "^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$";
		Pattern dobPat = Pattern.compile(dobRegex);
		Matcher matcher = dobPat.matcher(dob);
		return matcher.matches();
	}

}
