package com.tweetapp;

import java.io.IOException;
import java.util.Scanner;

import com.tweetapp.model.Register;
import com.tweetapp.service.InputValidation;
import com.tweetapp.service.LoginService;
import com.tweetapp.service.RegistrationService;
import com.tweetapp.service.ResetPasswordService;

public class MainMenu {

	Register register = new Register();
	static InputValidation input = new InputValidation();

	public static void main(String[] args) throws NumberFormatException, IOException {

		System.out.println("=============== Welcome to Twitter App =================");
		Scanner sc = new Scanner(System.in);
		Boolean exit = false;
		String isLoginEmail = null;
		boolean isNumber;
		while (true) {
			exit = false;
			System.out.println("====================================================");
			System.out.println("PRESS 1 to Login");
			System.out.println("PRESS 2 to Registration");
			System.out.println("PRESS 3 to Reset Password");
			System.out.println("PRESS 4 to Exit app");
			System.out.println("====================================================");
			System.out.print("Ente the choice: ");

			int c = sc.nextInt();
			// isNumber = input.isInteger(c);
			if (c == 1) {
				LoginService loginService = new LoginService();
				loginService.login();
			}

			else if (c == 2) {

				RegistrationService registrationService = new RegistrationService();
				registrationService.register();

			} else if (c == 3) {
				ResetPasswordService resetPasswordService = new ResetPasswordService();
				resetPasswordService.reset();
				// exit = false;

			} else if (c == 4) {
				// exit
				exit = true;
				break;
			} else {
				System.out.println("Please nter a valid choice");
			}
			if (exit == true) {

				break;
			}
		}
	}

}
