package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.tweetapp.DbUtil.CP;
import com.tweetapp.model.Register;

public class RegistrationDao {

	public static boolean insertUserToDb(Register register) {
		boolean f = false;
		try {
			Connection con = CP.create();
			String q = "insert into user(first_name, last_name, gender, dob, email, password) values(?,?,?,?,?,?)";
			// Prepared Statement
			PreparedStatement pstmt = con.prepareStatement(q);
			// set the value of parameters
			pstmt.setString(1, register.getFirst_name());
			pstmt.setString(2, register.getLast_name());
			pstmt.setString(3, register.getGender());
			pstmt.setString(4, register.getDob());
			pstmt.setString(5, register.getEmail());
			pstmt.setString(6, register.getPassword());

			// execute
			pstmt.executeUpdate();
			f = true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return f;
	}

}
