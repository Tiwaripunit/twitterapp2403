package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tweetapp.DbUtil.CP;

public class LoginDao {

	public static boolean validateLoginDb(String email, String password) {

		boolean flag = false;
		try {
			Connection con = CP.create();
			String queryString = " select count(*) as \"exists\" from user where email=? and password=?";
			// set this values using PreparedStatement
			PreparedStatement ps = con.prepareStatement(queryString);

			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet results = ps.executeQuery();

			if (results.next()) {
				int i = results.getInt("exists");
				if (i == 1) {
					// System.out.println("Username and Password exist");
					flag = true;
				} else {
					flag = false;
					// System.out.println("Please Check Username and Password ");
				}
			}
		} catch (SQLException sql) {

			System.out.println(sql);
		}
		return flag;
	}

}
