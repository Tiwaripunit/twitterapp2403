package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.tweetapp.DbUtil.CP;

public class ResetDao {

	public static boolean resetPasswordDb(String email, String password) {

		boolean f = false;
		try {
			Connection con = CP.create();
			String q = "update user set password = ? where email = ?";
			// Prepared Statement
			PreparedStatement pstmt = con.prepareStatement(q);
			// set the value of parameters
			pstmt.setString(1, password);
			pstmt.setString(2, email);

			// execute
			pstmt.executeUpdate();
			f = true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return f;
	}

}
