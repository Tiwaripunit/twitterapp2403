package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.tweetapp.DbUtil.CP;

public class PostTweetDao {

	public static boolean insertInDb(String messages, String email, String createAt) {
		boolean f = false;
		try {
			Connection con = CP.create();
			String q = "insert into tweet(messages, email, createAt) values(?,?,?)";
			// Prepared Statement
			PreparedStatement pstmt = con.prepareStatement(q);
			// set the value of parameters
			pstmt.setString(1, messages);
			pstmt.setString(2, email);
			pstmt.setString(3, createAt);

			// execute
			pstmt.executeUpdate();
			f = true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return f;// TODO Auto-generated method stub
	}

}
