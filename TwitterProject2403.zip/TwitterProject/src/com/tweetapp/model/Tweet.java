package com.tweetapp.model;

//This is the model class for tweet
public class Tweet {

	private Integer tweetId; // This field is for the tweet id
	private String messages; // This field is for the tweet message
	private String email;
	private String createAt; // This field is used to check the time tweet is posted

	public Integer getTweetId() {
		return tweetId;
	}

	public void setTweetId(Integer tweetId) {
		this.tweetId = tweetId;
	}

	public String getMessages() {
		return messages;
	}

	public void setMessages(String messages) {
		this.messages = messages;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreateAt() {
		return createAt;
	}

	public void setCreateAt(String createAt) {
		this.createAt = createAt;
	}

	// This is the parameterized constuctor for tweet
	public Tweet(Integer tweetId, String messages, String email, String createAt) {
		super();
		this.tweetId = tweetId;
		this.messages = messages;
		this.email = email;
		this.createAt = createAt;
	}

	@Override
	public String toString() {
		return "Tweet [tweetId=" + tweetId + ", messages=" + messages + ", email=" + email + ", createAt=" + createAt
				+ "]";
	}

	// default constructor for tweet
	public Tweet() {
		super();
	}

}
