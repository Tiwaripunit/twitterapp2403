export class Comment{
    replies : string;
    username  :  string;
}