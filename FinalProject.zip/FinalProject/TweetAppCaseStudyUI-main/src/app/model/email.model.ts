export class Email
{
    email : string;
}