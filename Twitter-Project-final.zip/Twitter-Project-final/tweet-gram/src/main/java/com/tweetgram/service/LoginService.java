package com.tweetgram.service;

import org.springframework.stereotype.Service;

import com.tweetgram.model.Login;
@Service
public interface LoginService {

	boolean loginUser(Login login);

	boolean saveUser(Login login);

	boolean updateUser(Login login);
	

}
