package com.tweetgram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetgram.dao.TweetRepository;
import com.tweetgram.model.TweetList;
@Service
public class TweetServiceImpl implements TweetService {

	@Autowired
	TweetRepository tweetRepository;
	@Override
	public boolean postTweet(TweetList tweet) {
		return tweetRepository.insert(tweet) != null;
	}

	@Override
	public List<TweetList> viewAllTweet() {
		return tweetRepository.findAll();
	}

}
