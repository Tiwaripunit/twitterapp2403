package com.tweetgram.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetgram.dao.LoginRepository;
import com.tweetgram.model.Login;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginRepository loginRepository;

	@Override
	public boolean loginUser(Login login) {
		System.out.println("2");
		java.util.Optional<Login> dbLogin = loginRepository.findById(login.getEmail());
		if (dbLogin != null&&dbLogin.get()!=null) {
			if (dbLogin.get().getPassword().equals(login.getPassword())) {
				System.out.println(dbLogin);
				return true;
			}
		}

		return false;
	}

	@Override
	public boolean saveUser(Login login) {

		return loginRepository.save(login) != null;

	}

	@Override
	public boolean updateUser(Login login) {
		System.out.println(login);
		Optional<Login> dbLogin= loginRepository.findById(login.getEmail());
		if(dbLogin!=null && dbLogin.get()!=null) {
			//loginRepository.deleteById(login.getEmail());
			dbLogin.get().setPassword(login.getPassword());
			return loginRepository.save(dbLogin.get()) != null;
		}
		return false;
	}
}
