
package com.tweetgram.dao;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetgram.model.Login;

@Repository
public interface LoginRepository extends CassandraRepository<Login, String> {
}
