import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { AppPostServiceService } from '../services/app-post-service.service';
// import { AppGetServiceService } from '../shared/services/app-get-service.service';
// import { DataServiceService } from '../shared/services/data-service.service';
import { Subscription } from 'rxjs';
import { promise } from 'protractor';
import * as moment from 'moment';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  options = {
    autoClose: false,
    keepAfterRouteChange: false
  };
  public signUpForm: FormGroup;
  public submitted = false;
  public invalidCredential = false;
  public invalidCredentialMessage: string;
  public groupDetails: any = {};
  private subsriptions: Subscription[] = [];
  public notificationMsg: any = '';
  public showNotificationFlag = false;
  public singupError = false;
  constructor(private router: Router, private formBuilder: FormBuilder, private appPostServiceService: AppPostServiceService){}
  //   private dataService: DataServiceService,
  //   private appPostServiceService: AppPostServiceService,
  //   private appGetServiceService: AppGetServiceService,
  //   protected alertService: AlertService) {

  // }

  ngOnInit(): void {
    this.setSignUpForm();
  }

  ngOnDestroy() {
    this.subsriptions.forEach(s => s.unsubscribe());
  }

  get formFields(): any  { return this.signUpForm.controls; }

  public onClickSignUp(formData): any  {
    this.checkPasswords(formData);
    if (this.signUpForm.invalid) {
      this.submitted = true;
      return;
    }
    
    const reqBody = {
      'email': this.signUpForm['controls']['userName'].value,
      'password': this.signUpForm['controls']['password'].value,
      'gender': this.signUpForm['controls']['gender'].value,
      'firstName': this.signUpForm['controls']['firstName'].value,
      'lastName': this.signUpForm['controls']['lastName'].value,
      'dob':  moment(this.signUpForm['controls']['dob'].value).format('YYYY-MM-DD'),
  };
    // console.log(reqBody);
    this.appPostServiceService.saveUser(reqBody).subscribe(res => {
      // this.loading = false;
      if (res) {
        alert ('Registration successful!!!');
        // this.storeCOOResponse = res['success']['responseMessage'];
        // this.notificationMsg = this.storeCOOResponse;
        // this.showNotificationFlag = true;
      }
    }, error => {
      // this.loading = false;
      // this.isAlertPopupOepn = true;
      alert('Error');
    });
    // this.validateSignUpUser(formData);
  }
  public showMessage(msg?): any  {
    this.singupError = true;

    this.showNotificationFlag = true;
    this.notificationMsg = msg;
  }

  public notificationClosed(flag): any {
    this.showNotificationFlag = flag;
  }

  private setSignUpForm(): any  {
    this.signUpForm = this.formBuilder.group({
      userName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      phoneNumber: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(12), Validators.pattern('^[0-9]*$')]],
      phoneCode: ['', [Validators.required, Validators.maxLength(3), Validators.pattern('^[0-9]*$')]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      gender: ['', Validators.required],
      dob: ['', Validators.required]
    });
  }

  public validateSignUpUser(formData): any  {
    this.invalidCredential = false;
    const encryptedPassword = btoa(formData.controls.password.value);
    const signupData = {
      'emailId': (formData.controls.emailId.value).toLowerCase(),
      'userName': formData.controls.userName.value,
      'phoneNumber': '+' + formData.controls.phoneCode.value + formData.controls.phoneNumber.value,
      'password': formData.controls.password.value,
      'firstTimeLogin': true
    };
    this.createUser(signupData);
  }
  private createUser(signupData): any  {
  }
  public checkPasswords(formData): any  {
    const pass = formData.controls.password.value;
    const confirmPass = formData.controls.confirmPassword.value;

    if (pass !== confirmPass) {
      formData.controls.confirmPassword.setErrors({ 'different': true });
    }
  }

  public backToLogin(): any  {
    this.router.navigate(['/']);
  }

}
