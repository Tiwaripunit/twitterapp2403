import { Component, OnInit, Input } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { AppPostServiceService } from '../services/app-post-service.service';
import { AppGetServiceService } from '../services/app-get-service.service';

@Component({
  selector: 'app-tweet',
  templateUrl: './tweet.component.html',
  styleUrls: ['./tweet.component.scss']
})
export class TweetComponent implements OnInit {

  postTweetForm: FormGroup;
  public pageUrl: any;
  public tweetData = {};
  public tweetList = [];
  public currentUser;
  submitted = false;
  public tweetObj = {
    firstName : "xxx",
    handleName : "xxx",
    tweetTime : "Just now",
    tweetText : "xxx",
    phone : "xxx",
    lastName : "xxx",
    userId : "1000",
    email : "xxx",
  };
  //@Input() userLoginId;

  constructor(public router: Router, private httpClient: HttpClient, private formBuilder: FormBuilder, private appGetServiceService: AppGetServiceService,
              private appPostServiceService: AppPostServiceService) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        // Show loading indicator
        this.pageUrl = event.url;
        // setTimeout(() => {
        //   this.getLoginUser();
        // }, 10);
      }
    });
  }

  get formFields(): any { return this.postTweetForm.controls; }

  ngOnInit(): void {
    // this.postTweetForm = this.formBuilder.group({
    //   postTweet: ['', Validators.required]
    // });
    this.createTweetForm();
    this.getTweetList();
    // this.httpClient.get('./../assets/allTweetsResponse.json').subscribe(data => {
      // console.log(data);
      // this.tweetData = data;
      //this.tweetList = data['success']['data']['searchResults'];
      //console.log(this.tweetList);
      // if (data.type === 'Success') {
       // const { searchResults } = data.response;
    //});
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    console.log(this.currentUser);
  }

  private createTweetForm(): any {
    this.postTweetForm = this.formBuilder.group({
      post_tweet: ['', Validators.required]
    });
  }

  public postTweet(value): any{
    // if (value !== '') {
    //   alert ('tweet posted successfully');
    //   this.postTweetForm.controls.post_tweet.setValue('');
    //   //this.postTweetForm.controls.post_tweet.setErrors({ 'required': false });
    //   // this.postTweetForm.controls.post_tweet.setErrors({ 'is-invalid': false });
    //   // this.submitted = false;
    //   //this.tweetObj.handleName = this.currentUser;
    //   //this.tweetObj.tweetText = value;
    //   // this.tweetList.push(this.tweetObj);
    //   // this.tweetList.splice(0, 0, this.tweetObj);


    // }
    // if (this.postTweetForm.invalid) {
    //   this.submitted = true;
    //   return;
    // }

    if (this.postTweetForm.invalid) {
      this.submitted = true;
      return;
    }
    // this.alertService.clear();
    // this.Auth.authorizeUser(formData);
    const reqBody = {
      "tweetId": {
          "email": this.currentUser,
          "tweetText": value
    },
      "loginStatus": "y"
  };
    // console.log(reqBody);
    this.appPostServiceService.postTweet(reqBody).subscribe(res => {
      // this.loading = false;
      if (res) {
        alert ('Tweet posted successfully!!!');
        this.postTweetForm.controls.post_tweet.setValue('');
        this.getTweetList();
      }
    }, error => {
      alert('Something is wrong.Please try again...');
    });
  }

  public getTweetList() {
    this.appGetServiceService.viewAllTweet().subscribe(res => {
      // this.loading = false;
      if (res.length !== 0) {
        this.tweetList = res;
      } else {
        // alert('No tweets to show...');
      }
    }, error => {
      // alert('Something is wrong. Please try again...');
    });
  }
  

}
