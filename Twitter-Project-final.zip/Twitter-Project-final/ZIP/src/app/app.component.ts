import { Component } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'TweetApp';

  public pageUrl: any;
  public loginId;
  constructor(public router: Router) {
    this.router.events.subscribe((event) => {
         if (event instanceof NavigationStart) {
            this.pageUrl = event.url;
        }
    });
  }

  ngOnInit(): void {
  }
}
