import { Component, OnInit, ViewEncapsulation, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { AppPostServiceService } from '../services/app-post-service.service';
// import { DataServiceService } from '../shared/services/data-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  // @Output() loginId: EventEmitter<string> = new EventEmitter();

  // constructor(private router: Router, private dataService: DataServiceService,private formBuilder: FormBuilder){}
  constructor(private router: Router, private formBuilder: FormBuilder, private appPostServiceService: AppPostServiceService){}

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      userId: ['', Validators.required],
      password: ['', Validators.required],
    });
    localStorage.removeItem('currentUserData');
  }

  public signUp(): any {
    this.router.navigate(['/signup']);
  }

  get formFields(): any { return this.loginForm.controls; }

    onClickSubmit(formData): any {
    // if (this.loginForm.controls.userId.value === '@jewel_saha' && this.loginForm.controls.password.value === 'admin') {
    //   this.router.navigate(['/tweet']);
    //   localStorage.setItem('currentUser', JSON.stringify(this.loginForm.controls.userId.value));
    //   // this.loginId.emit(this.loginForm.controls.userId.value);
    // }
    //public login() {
    if (this.loginForm.invalid) {
      this.submitted = true;
      return;
    }
    // this.alertService.clear();
    // this.Auth.authorizeUser(formData);
    const reqBody = {
      'email': this.loginForm['controls']['userId'].value,
      'password': this.loginForm['controls']['password'].value
    };
    // console.log(reqBody);
    this.appPostServiceService.loginUser(reqBody).subscribe(res => {
      // this.loading = false;
      if (res) {
        alert ('Login successful!!!');
        this.router.navigate(['/tweet']);
        localStorage.setItem('currentUser', JSON.stringify(this.loginForm.controls.userId.value));
      }
    }, error => {
      alert('Login failed...Please register first');
      this.loginForm.controls.userId.setValue('');
      this.loginForm.controls.password.setValue('');
    });
  }

  public login() {
    
  }

}
