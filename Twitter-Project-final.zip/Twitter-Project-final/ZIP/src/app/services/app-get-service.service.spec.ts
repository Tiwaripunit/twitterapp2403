import { TestBed } from '@angular/core/testing';

import { AppGetServiceService } from './app-get-service.service';

describe('AppGetServiceService', () => {
  let service: AppGetServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppGetServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
