import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, NavigationStart } from '@angular/router';
import { AppGetServiceService } from '../services/app-get-service.service';

@Component({
  selector: 'app-alltweet',
  templateUrl: './alltweet.component.html',
  styleUrls: ['./alltweet.component.scss']
})
export class AlltweetComponent implements OnInit {

  public pageUrl: any;
  public tweetList = [];
  public currentUser;

  constructor(public router: Router, private httpClient: HttpClient, private appGetServiceService: AppGetServiceService) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        // Show loading indicator
        this.pageUrl = event.url;
        // setTimeout(() => {
        //   this.getLoginUser();
        // }, 10);
      }
    });
  }

  ngOnInit(): void {
    // this.httpClient.get('./../assets/allTweetsResponse.json').subscribe(data => {
      // this.tweetList = data['success']['data']['searchResults'];
      // if (data.type === 'Success') {
       // const { searchResults } = data.response;
       this.showAllTweets();
   // });
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  public showAllTweets() {
    this.appGetServiceService.viewAllTweet().subscribe(res => {
      // this.loading = false;
      if (res.length !== 0) {
        this.tweetList = res;
      } else {
        alert('No tweets to show...');
      }
    }, error => {
      alert('Something is wrong. Please try again...');
    });
  }

}
